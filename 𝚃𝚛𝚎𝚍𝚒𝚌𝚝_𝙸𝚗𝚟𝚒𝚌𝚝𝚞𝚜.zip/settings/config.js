module.exports = {
  tokenBot: "BOT_TOKEN",
  ownerID: "5126860596",
  adminID: "5126860596",
};